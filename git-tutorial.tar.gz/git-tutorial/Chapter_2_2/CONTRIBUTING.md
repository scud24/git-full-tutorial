Zaphod Beeblebrox
Epicurus
Hypatia
Zaphod Rules! 42